class CSVCalculatorHandler:
    def __init__(self):
        pass

    def process_csvs(self, filenames, output_prefix="output"):
        pass

    def save_to_history(self, filename, operation, result, error_code):
        pass

    def history_export(self, export_filename):
        pass


if __name__ == '__main__':
    print("write some code, your testing software will call this main function")
